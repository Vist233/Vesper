import { corePlugins, createAgent } from 'sakura-agent';
import { createSakuraBrowserPlugin } from 'sakura-browser-tool';

/** Keep the sandbox/VM environment bound to the same Agent as agentId. */
export function createAgentWithBrowser({ agentId, environment, model, imageDirectory }) {
  return createAgent({
    model,
    cwd: environment.cwd,
    environment,
    tools: [],
    plugins: [...corePlugins(), createSakuraBrowserPlugin({ agentId, imageDirectory })],
  });
}
