# 第三方依赖

- `agent-browser@0.41.1` 来自 Vercel，按 [Apache-2.0](https://raw.githubusercontent.com/vercel-labs/agent-browser/v0.41.1/LICENSE) 发布。npm 包声明依赖，发布包未内嵌上游源码或二进制。由 npm 按 `npm-shrinkwrap.json` 安装。
- Chromium 和 Xvfb 由 Linux 系统或验收镜像提供，沿用其上游授权。Sakura SDK 由宿主应用提供。
