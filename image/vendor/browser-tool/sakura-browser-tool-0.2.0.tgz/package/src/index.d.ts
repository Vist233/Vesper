export type Point = [number, number];
type Verified = { expectText?: string };
export type BrowserAction =
  | ({ action: 'open' | 'new_tab'; url: string } & Verified)
  | { action: 'snapshot' | 'tabs' | 'screenshot' }
  | { action: 'read_text' | 'get_box'; target: string }
  | ({ action: 'click'; target: string } & Verified)
  | ({ action: 'fill'; target: string; text: string } & Verified)
  | ({ action: 'press'; key: string } & Verified)
  | ({ action: 'mouse_click'; point: Point } & Verified)
  | ({ action: 'drag'; points: Point[] } & Verified)
  | { action: 'scroll'; direction: 'up' | 'down' | 'left' | 'right'; pixels: number }
  | { action: 'switch_tab'; tab: string };

export interface BrowserEnvironment {
  exec(command: string, options: { timeoutMs: number; signal?: AbortSignal }):
    Promise<{ exitCode: number | null; output: string; timedOut: boolean }>;
  readFile?(path: string): Promise<Uint8Array>;
}
export interface BrowserToolOptions {
  agentId: string;
  environment?: BrowserEnvironment;
  workerCommand?: string[];
  /** Enable image return only for an image-capable model. */
  imageDirectory?: string;
}
type Text = { type: 'text'; text: string };
type Image = { type: 'image'; mediaType: 'image/png'; ref: string };
export interface BrowserTool {
  name: 'browser';
  description: string;
  parameters: Record<string, unknown>;
  effect: 'write';
  replay: 'never';
  executionMode: 'serial';
  execute(action: unknown, context?: { env: BrowserEnvironment; signal: AbortSignal }):
    Promise<{ content: (Text | Image)[]; isError: boolean }>;
}
export function encodeBrowserRequest(agentId: string, action: BrowserAction): string;
export function createBrowserTool(options: BrowserToolOptions): BrowserTool;
export function createSakuraBrowserPlugin(options: BrowserToolOptions): {
  name: string;
  setup(api: { registerTool(tool: BrowserTool): void }): void;
};
