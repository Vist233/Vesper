const text = (maxLength) => ({ type: 'string', minLength: 1, maxLength });
const target = text(512);
const coordinate = { type: 'integer', minimum: 0, maximum: 8192 };
const point = { type: 'array', items: coordinate, minItems: 2, maxItems: 2 };
const fields = {
  open: { url: text(4096) },
  snapshot: {},
  read_text: { target },
  get_box: { target },
  click: { target },
  fill: { target, text: { type: 'string', maxLength: 8000 } },
  press: { key: text(64) },
  scroll: { direction: { type: 'string', enum: ['up', 'down', 'left', 'right'] }, pixels: coordinate },
  tabs: {},
  switch_tab: { tab: text(80) },
  new_tab: { url: text(4096) },
  mouse_click: { point },
  drag: { points: { type: 'array', items: point, minItems: 2, maxItems: 80 } },
  screenshot: {},
};
const verifiable = new Set(['open', 'new_tab', 'click', 'fill', 'press', 'mouse_click', 'drag']);

export const maxRequestBytes = 24_000;
export const timeoutMs = 35_000;
export const maxImageBytes = 2 * 1024 * 1024;
export const parameters = {
  type: 'object',
  properties: {
    action: { type: 'string', enum: Object.keys(fields) },
    ...Object.assign({}, ...Object.values(fields)),
    expectText: { ...text(500), description: 'Optional visible text to verify after a change.' },
  },
  required: ['action'], additionalProperties: false,
};

function matches(value, rule) {
  if (rule.type === 'array') return Array.isArray(value) && value.length >= rule.minItems &&
    value.length <= rule.maxItems && value.every((item) => matches(item, rule.items));
  if (rule.type === 'integer') return Number.isInteger(value) && value >= rule.minimum && value <= rule.maximum;
  return typeof value === 'string' && !value.includes('\0') && value.length >= (rule.minLength ?? 0) &&
    value.length <= (rule.maxLength ?? Infinity) && (!rule.enum || rule.enum.includes(value));
}

export function checkAction(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || !Object.hasOwn(fields, value.action)) {
    throw new Error('Unknown browser action.');
  }
  const required = fields[value.action];
  const allowed = verifiable.has(value.action) ? { ...required, expectText: parameters.properties.expectText } : required;
  for (const name of Object.keys(required)) {
    if (!Object.hasOwn(value, name)) throw new Error(`Missing ${name}.`);
  }
  for (const [name, arg] of Object.entries(value)) {
    if (name === 'action') continue;
    if (!Object.hasOwn(allowed, name) || !matches(arg, allowed[name])) throw new Error(`Invalid ${name}.`);
  }
  if (value.url) {
    let url;
    try { url = new URL(value.url); } catch { throw new Error('Invalid URL.'); }
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
      throw new Error('Use HTTP(S) without embedded credentials.');
    }
  }
  for (const name of ['target', 'key', 'tab', 'expectText']) {
    if (value[name] && value[name].trimStart().startsWith('-')) throw new Error(`Invalid ${name}.`);
  }
  // The pinned CLI parses global flags anywhere in argv, including after fill's selector.
  if (value.action === 'fill' && /^-{1,2}[a-z]/i.test(value.text.trimStart())) {
    throw new Error('Fill text cannot begin with a CLI option name in this version.');
  }
  if (value.action === 'switch_tab' && !/^(t[1-9][0-9]*|[a-f0-9]{32})$/i.test(value.tab)) {
    throw new Error('Use the tabId or targetId returned by tabs.');
  }
  return value;
}

export function checkAgentId(id) {
  if (typeof id !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,31}$/.test(id)) {
    throw new Error('Set a valid agentId (1–32 letters, digits, hyphens or underscores).');
  }
  return id;
}
