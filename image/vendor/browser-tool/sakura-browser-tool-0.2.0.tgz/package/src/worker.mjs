#!/usr/bin/env node
import { execFile } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { lstat, mkdir, realpath } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { homedir, tmpdir } from 'node:os';
import { dirname, isAbsolute, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { checkAction, checkAgentId, maxRequestBytes } from './protocol.mjs';

const exec = promisify(execFile);
const env = process.env;
const require = createRequire(import.meta.url);
const configPath = fileURLToPath(new URL('./agent-browser.json', import.meta.url));
const maxText = 12_000;

async function privateDirectory(path) {
  await mkdir(path, { recursive: true, mode: 0o700 });
  const info = await lstat(path);
  if (!info.isDirectory() || info.uid !== process.getuid() || (info.mode & 0o077)) {
    throw new Error('Browser state directory must be owned by the worker and private (0700).');
  }
  return realpath(path);
}

function loopbackEndpoint(value) {
  if (!value) throw new Error('Set BROWSER_TOOL_CDP to the workspace Chrome debugging endpoint.');
  const url = new URL(value);
  if (!['http:', 'ws:'].includes(url.protocol) || url.hostname !== '127.0.0.1' || !url.port ||
      url.username || url.password || url.search || url.hash ||
      (url.protocol === 'http:' && url.pathname !== '/') ||
      (url.protocol === 'ws:' && !/^\/devtools\/browser\/[\w-]+$/.test(url.pathname))) {
    throw new Error('BROWSER_TOOL_CDP must be a loopback Chrome debugging endpoint.');
  }
  return url.href;
}

async function browserClient(agentId, endpoint) {
  const root = env.BROWSER_TOOL_ROOT || join(homedir(), '.sakura-browser');
  if (!isAbsolute(root)) throw new Error('BROWSER_TOOL_ROOT must be absolute.');
  const agentHome = await privateDirectory(join(await privateDirectory(root), agentId));
  const hash = createHash('sha256').update(`${agentHome}\0${endpoint}`).digest('hex').slice(0, 24);
  // Keep the Unix socket path short, including on macOS.
  const sockets = await privateDirectory(join('/tmp', `sbt-${process.getuid()}-${hash}`));
  const flags = ['--config', configPath, '--session', 'browser', '--json', '--pin-tab', '--cdp', endpoint];
  // Chrome runs in the workspace already. The CLI needs no display or model credentials.
  const childEnv = { HOME: homedir(), PATH: env.PATH || '/usr/bin:/bin', TMPDIR: tmpdir(),
    AGENT_BROWSER_SOCKET_DIR: sockets, AGENT_BROWSER_NO_AUTO_DIALOG: '1' };
  const bin = join(dirname(require.resolve('agent-browser/package.json')), 'bin', 'agent-browser.js');
  async function call(args, timeout = 14_000) {
    let stdout;
    try {
      ({ stdout } = await exec(process.execPath, [bin, ...flags, ...args], {
        cwd: agentHome, env: childEnv, timeout, maxBuffer: 1024 * 1024,
      }));
    } catch (error) {
      if (error.killed) throw new Error('Browser command timed out. Its effects may already have occurred.');
      stdout = error.stdout;
    }
    let response;
    try { response = JSON.parse(stdout); } catch { throw new Error('Browser CLI did not return JSON.'); }
    if (Array.isArray(response) && args[0] === 'batch') {
      const failed = response.find((item) => !item.success);
      if (failed) throw new Error(String(failed.error || 'A mouse event failed.').slice(0, 1000));
      if (response.length !== args.length - 2) throw new Error('Mouse batch did not complete.');
      return response;
    }
    if (!response.success) throw new Error(String(response.error || 'Browser command failed.').slice(0, 1000));
    return response.data;
  }
  return { call, agentHome };
}

function commandFor(action) {
  switch (action.action) {
    case 'open': return ['open', action.url];
    case 'snapshot': return ['snapshot', '-i', '-c'];
    case 'read_text': return ['get', 'text', action.target];
    case 'get_box': return ['get', 'box', action.target];
    case 'click': return ['click', action.target];
    case 'fill': return ['fill', action.target, action.text];
    case 'press': return ['press', action.key];
    case 'scroll': return ['scroll', action.direction, String(action.pixels)];
    case 'tabs': return ['tab', 'list'];
    case 'switch_tab': return ['tab', action.tab];
    case 'new_tab': return ['tab', 'new', action.url];
    default: throw new Error('Unsupported browser command.');
  }
}

async function pointerAction(call, points) {
  const [start, ...rest] = points.map(([x, y]) => `mouse move ${x} ${y}`);
  try {
    await call(['batch', '--bail', start, 'mouse down left', ...rest, 'mouse up left']);
  } catch (error) {
    await call(['mouse', 'up', 'left'], 2000).catch(() => {});
    throw error;
  }
  return { eventsDispatched: true };
}

function limited(data) {
  const encoded = JSON.stringify(data ?? null);
  if (encoded.length <= maxText) return data ?? null;
  return { preview: encoded.slice(0, maxText), truncated: true };
}

async function perform(client, request) {
  const { call, agentHome } = client;
  if (request.action === 'screenshot') {
    const path = join(await privateDirectory(join(agentHome, 'artifacts')), `${randomUUID()}.png`);
    await call(['screenshot', path]);
    const info = await lstat(path);
    if (!info.isFile()) throw new Error('Browser did not create a screenshot.');
    return { ok: true, data: { path, bytes: info.size } };
  }
  let data;
  if (request.action === 'drag' || request.action === 'mouse_click') {
    data = await pointerAction(call, request.points ?? [request.point]);
  } else data = await call(commandFor(request));
  if (!request.expectText) return { ok: true, data: limited(data) };
  try {
    await call(['wait', '--text', request.expectText, '--timeout', '5000'], 7000);
    return { ok: true, verified: true, data: limited(data) };
  } catch {
    return { ok: false, actionDispatched: true, verified: false, error: 'Expected text was not confirmed. Inspect before retrying.' };
  }
}

let agentId;
try {
  agentId = checkAgentId(env.BROWSER_TOOL_AGENT_ID);
  const [operation, token] = process.argv.slice(2);
  if (operation !== 'call') throw new Error('Use call BASE64URL. The workspace owner manages Chrome.');
  if (!token || token.length > Math.ceil(maxRequestBytes * 4 / 3) || !/^[A-Za-z0-9_-]+$/.test(token)) {
    throw new Error('Invalid request envelope.');
  }
  const input = JSON.parse(Buffer.from(token, 'base64url').toString('utf8'));
  if (input.agentId !== agentId) throw new Error('Worker does not belong to this Agent.');
  const request = checkAction(input.action);
  const endpoint = loopbackEndpoint(env.BROWSER_TOOL_CDP);
  const result = await perform(await browserClient(agentId, endpoint), request);
  console.log(JSON.stringify({ agentId, ...result }));
} catch (error) {
  console.log(JSON.stringify({ agentId, ok: false, error: String(error.message).slice(0, 1000) }));
}
