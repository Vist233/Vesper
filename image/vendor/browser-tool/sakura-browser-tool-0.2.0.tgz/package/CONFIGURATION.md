# 总体 Agent 的浏览器配置备忘

总体 Agent 为每个工作区分配自己的桌面和 Chrome 数据目录。浏览器工具和桌面工具指向同一个工作区，操作的是同一扇 Chrome 窗口。可在工作区直接调用 Vercel 的 `agent-browser`，也可选择 [Sakura 接入层](README.md)来注册结构化 Tool。

## 接入时配置

1. 在该 Linux 工作区启动可见的 Chrome。为这个 Agent 使用独立的 `--user-data-dir`，并把调试端点留在工作区内的 `127.0.0.1`。每个工作区有独立网络时可以复用端口 `9222`。
2. 在该工作区的项目里安装上游 `agent-browser`，锁定实际验收过的版本。Sakura 通过已绑定工作区的执行接口调用该命令。用这个工作区的终端做只读检查和截图。

   ```sh
   npx --no-install agent-browser --cdp 9222 snapshot
   npx --no-install agent-browser --cdp 9222 screenshot ./browser-check.png
   ```

3. 浏览器操作需要页面结构时用 `agent-browser`。需要控制桌面应用、系统弹窗或其他窗口时，用单独的桌面工具。模型需要看截图时，由宿主读回截图并按客户端能力传图。
4. 先用测试页面验收。网站要求登录或 2FA 时，由用户接管该窗口完成。登录凭据和会话文件留在授权工作区。

这里的命令供总体 Agent 接入时使用。iPhone 控制继续用独立的 MCP 项目。

[上游安装文档](https://agent-browser.dev/installation) · [上游 CDP 文档](https://agent-browser.dev/cdp-mode)
