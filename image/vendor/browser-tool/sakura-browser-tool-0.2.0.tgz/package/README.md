# Sakura Browser Tool

`v0.2.0` 是 Sakura 的可选浏览器接入层。它在 Agent 已绑定的工作区中调用 Vercel 的 `agent-browser`，操作该工作区已经启动的 Chrome。Sakura 多一个结构化的 `browser` Tool，能收到页面快照和可选的图片结果。

## 各层负责什么

| 层 | 职责 |
| --- | --- |
| 总体 Agent | 为每个 Agent 分配工作区，启动可见 Chrome，管理桌面、浏览器数据、连接权限和登录。 |
| `agent-browser` | 通过 CDP 执行网页动作。包使用 `agent-browser@0.41.1`，由 npm 安装上游依赖。 |
| Sakura 接入层 | 注册一个 Tool，校验动作，把调用发到对应工作区，串行执行并回传结果。 |

在工作区里直接用 CLI 也可以。用法见 [配置备忘](CONFIGURATION.md)。桌面工具可以在同一个工作区操纵 Chrome 窗口及其他应用。iPhone 控制继续走独立的 MCP。

## 安装和注册

1. 在 Sakura 宿主和浏览器工作区安装同一个 `.tgz`。工作区需要 Node.js 24 或更高版本，并能从 PATH 找到 `sakura-browser-worker`。也可在宿主配置中用 `workerCommand` 指定可信的绝对路径。

   ```sh
   npm install --save-exact /absolute/path/sakura-browser-tool-0.2.0.tgz
   ```

2. 由工作区启动器打开 Chrome。配置独立的用户数据目录。让调试端点只监听工作区回环地址，再为 worker 设置以下变量。

   ```sh
   export BROWSER_TOOL_AGENT_ID=agent-a
   export BROWSER_TOOL_CDP=http://127.0.0.1:9222
   ```

   `BROWSER_TOOL_ROOT` 可选。默认用 `~/.sakura-browser` 保存截图和接入层状态。目录须由 worker 用户拥有，权限为 `0700`。Chrome 的用户数据目录由工作区单独管理。

3. 在该 Agent 的现有 `plugins` 配置中追加插件。`agentId` 必须与工作区的配置一致。插件默认使用 Sakura 已绑定的执行环境。浏览器在单独的工作区时，可显式传 `environment: browserWorkspace`。

   ```ts
   import { createSakuraBrowserPlugin } from 'sakura-browser-tool';

   const browser = createSakuraBrowserPlugin({ agentId: 'agent-a' });
   // plugins: [...existingPlugins, browser]
   ```

4. 先用测试页面验收。遇到登录或 2FA，由用户在该窗口完成。当前工作区的网络和文件访问权限由宿主管理。每个 Agent 使用独立的工作区、浏览器数据目录和回环端点。

`v0.2.0` 要求配置 `BROWSER_TOOL_CDP`。缺少配置、指定外部地址或目标不可达时，工具返回错误。Chrome 的启动、停止和恢复由工作区负责。旧版的自启动配置和 `stop` 命令已退出接入层。

## Tool 接口

```json
{ "action": "open", "url": "https://example.com" }
```

| 动作 | 参数 |
| --- | --- |
| `snapshot` | 返回交互元素和 `@e` 引用。页面变化后重新获取。 |
| `read_text`、`get_box`、`click`、`fill` | `target` 为 `@e` 引用或 CSS。`fill` 还需要 `text`。参数中形似 CLI 选项的开头会被拒绝。 |
| `press`、`scroll` | 分别用 `key` 或 `direction` 与 `pixels`。 |
| `tabs`、`switch_tab`、`new_tab` | 分别用于列出、按标签 ID 切换、按 URL 新建标签页。 |
| `mouse_click`、`drag` | 用网页视口中的 `point: [x, y]` 或 `points: [[x1, y1], ...]`。 |
| `screenshot` | 返回工作区内的 PNG 路径和大小。 |

部分交互可传 `expectText`，核对动作后页面是否出现指定文字。文字可能已在页面上，因此核对结果无法证明是该动作产生的。`actionDispatched: true` 表示动作已发出但条件未确认。再次尝试前先检查页面。Sakura 把该 Tool 视为写操作，恢复会话时不会自动重放。

给支持视觉的模型配置 `imageDirectory` 后，插件可通过环境的 `readFile` 将 PNG 复制到宿主并返回图片块。PNG 最大为 2 MiB。文本模型用默认的路径输出。

## 测试和来源

本地源码可运行 `npm test`。双 Linux 桌面测试使用源码目录中的测试镜像与 `examples/verify-linux.mjs`。安装包内有 [验收记录](VALIDATION.md) 和 [上游授权说明](THIRD_PARTY_NOTICES.md)。

[agent-browser 项目](https://github.com/vercel-labs/agent-browser) · [CDP 接入说明](https://agent-browser.dev/cdp-mode)
